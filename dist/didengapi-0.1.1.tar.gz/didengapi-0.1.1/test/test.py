from DidengAPI import client
Xs = client.DidengAPI()
print(Xs.get_info())