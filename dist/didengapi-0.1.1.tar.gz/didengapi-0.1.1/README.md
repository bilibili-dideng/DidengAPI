# DidengAPI

A lightweight Python client for accessing web services.

## Install

```bash
pip install Didengapi