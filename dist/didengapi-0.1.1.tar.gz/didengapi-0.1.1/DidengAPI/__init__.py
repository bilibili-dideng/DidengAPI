# didengapi/__init__.py
from .client import DidengAPI

__version__ = "0.1.0"
__author__ = "Your Name"

__all__ = ["DidengAPI"]